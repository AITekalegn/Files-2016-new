﻿namespace LibrarySystem
{
    partial class frmOverdue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Label34 = new System.Windows.Forms.Label();
            this.txtChange = new System.Windows.Forms.TextBox();
            this.Label33 = new System.Windows.Forms.Label();
            this.txttenderedAmount = new System.Windows.Forms.TextBox();
            this.Label35 = new System.Windows.Forms.Label();
            this.Label36 = new System.Windows.Forms.Label();
            this.Label37 = new System.Windows.Forms.Label();
            this.Label38 = new System.Windows.Forms.Label();
            this.TextBox7 = new System.Windows.Forms.TextBox();
            this.Label39 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.txttothours = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label40 = new System.Windows.Forms.Label();
            this.txtSearchPborrower = new System.Windows.Forms.TextBox();
            this.dtgPenalties = new System.Windows.Forms.DataGridView();
            this.GroupBox10 = new System.Windows.Forms.GroupBox();
            this.txtamount = new System.Windows.Forms.TextBox();
            this.Label29 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.Label30 = new System.Windows.Forms.Label();
            this.btnPenClose = new System.Windows.Forms.Button();
            this.Label32 = new System.Windows.Forms.Label();
            this.txtTotPay = new System.Windows.Forms.TextBox();
            this.txtOverdueTime = new System.Windows.Forms.TextBox();
            this.Label28 = new System.Windows.Forms.Label();
            this.GroupBox9 = new System.Windows.Forms.GroupBox();
            this.Label27 = new System.Windows.Forms.Label();
            this.btnPenNew = new System.Windows.Forms.Button();
            this.btnPSave = new System.Windows.Forms.Button();
            this.GroupBox7 = new System.Windows.Forms.GroupBox();
            this.Label31 = new System.Windows.Forms.Label();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.txthours = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.dtgPenalties)).BeginInit();
            this.GroupBox10.SuspendLayout();
            this.GroupBox9.SuspendLayout();
            this.GroupBox7.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txthours)).BeginInit();
            this.SuspendLayout();
            // 
            // Label34
            // 
            this.Label34.AutoSize = true;
            this.Label34.Location = new System.Drawing.Point(71, 26);
            this.Label34.Name = "Label34";
            this.Label34.Size = new System.Drawing.Size(53, 17);
            this.Label34.TabIndex = 7;
            this.Label34.Text = "Label25";
            // 
            // txtChange
            // 
            this.txtChange.Enabled = false;
            this.txtChange.Location = new System.Drawing.Point(145, 258);
            this.txtChange.Name = "txtChange";
            this.txtChange.Size = new System.Drawing.Size(254, 25);
            this.txtChange.TabIndex = 16;
            // 
            // Label33
            // 
            this.Label33.AutoSize = true;
            this.Label33.Location = new System.Drawing.Point(80, 261);
            this.Label33.Name = "Label33";
            this.Label33.Size = new System.Drawing.Size(59, 17);
            this.Label33.TabIndex = 15;
            this.Label33.Text = "Change :";
            // 
            // txttenderedAmount
            // 
            this.txttenderedAmount.Location = new System.Drawing.Point(145, 227);
            this.txttenderedAmount.Name = "txttenderedAmount";
            this.txttenderedAmount.Size = new System.Drawing.Size(254, 25);
            this.txttenderedAmount.TabIndex = 14;
            this.txttenderedAmount.TextChanged += new System.EventHandler(this.txttenderedAmount_TextChanged);
            // 
            // Label35
            // 
            this.Label35.AutoSize = true;
            this.Label35.Location = new System.Drawing.Point(71, 52);
            this.Label35.Name = "Label35";
            this.Label35.Size = new System.Drawing.Size(53, 17);
            this.Label35.TabIndex = 4;
            this.Label35.Text = "Label25";
            // 
            // Label36
            // 
            this.Label36.AutoSize = true;
            this.Label36.Location = new System.Drawing.Point(75, 122);
            this.Label36.Name = "Label36";
            this.Label36.Size = new System.Drawing.Size(53, 17);
            this.Label36.TabIndex = 6;
            this.Label36.Text = "Label26";
            // 
            // Label37
            // 
            this.Label37.AutoSize = true;
            this.Label37.Location = new System.Drawing.Point(15, 122);
            this.Label37.Name = "Label37";
            this.Label37.Size = new System.Drawing.Size(59, 17);
            this.Label37.TabIndex = 5;
            this.Label37.Text = "Change :";
            // 
            // Label38
            // 
            this.Label38.AutoSize = true;
            this.Label38.Location = new System.Drawing.Point(6, 87);
            this.Label38.Name = "Label38";
            this.Label38.Size = new System.Drawing.Size(119, 17);
            this.Label38.TabIndex = 3;
            this.Label38.Text = "Tendered Amount :";
            // 
            // TextBox7
            // 
            this.TextBox7.Location = new System.Drawing.Point(132, 84);
            this.TextBox7.Name = "TextBox7";
            this.TextBox7.Size = new System.Drawing.Size(177, 25);
            this.TextBox7.TabIndex = 2;
            // 
            // Label39
            // 
            this.Label39.AutoSize = true;
            this.Label39.Location = new System.Drawing.Point(6, 52);
            this.Label39.Name = "Label39";
            this.Label39.Size = new System.Drawing.Size(70, 17);
            this.Label39.TabIndex = 1;
            this.Label39.Text = "Payments :";
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(382, 38);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(34, 17);
            this.Label4.TabIndex = 11;
            this.Label4.Text = "hr(s)";
            // 
            // txttothours
            // 
            this.txttothours.Enabled = false;
            this.txttothours.Location = new System.Drawing.Point(318, 35);
            this.txttothours.Name = "txttothours";
            this.txttothours.Size = new System.Drawing.Size(64, 25);
            this.txttothours.TabIndex = 18;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label3.Location = new System.Drawing.Point(279, 38);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(17, 17);
            this.Label3.TabIndex = 11;
            this.Label3.Text = "=";
            // 
            // Label40
            // 
            this.Label40.AutoSize = true;
            this.Label40.Location = new System.Drawing.Point(6, 26);
            this.Label40.Name = "Label40";
            this.Label40.Size = new System.Drawing.Size(70, 17);
            this.Label40.TabIndex = 0;
            this.Label40.Text = "Over Due :";
            // 
            // txtSearchPborrower
            // 
            this.txtSearchPborrower.Location = new System.Drawing.Point(96, 42);
            this.txtSearchPborrower.Name = "txtSearchPborrower";
            this.txtSearchPborrower.Size = new System.Drawing.Size(263, 25);
            this.txtSearchPborrower.TabIndex = 23;
            this.txtSearchPborrower.TextChanged += new System.EventHandler(this.txtSearchPborrower_TextChanged);
            // 
            // dtgPenalties
            // 
            this.dtgPenalties.AllowUserToAddRows = false;
            this.dtgPenalties.AllowUserToDeleteRows = false;
            this.dtgPenalties.AllowUserToResizeColumns = false;
            this.dtgPenalties.AllowUserToResizeRows = false;
            this.dtgPenalties.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgPenalties.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgPenalties.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgPenalties.Location = new System.Drawing.Point(9, 73);
            this.dtgPenalties.MultiSelect = false;
            this.dtgPenalties.Name = "dtgPenalties";
            this.dtgPenalties.RowHeadersVisible = false;
            this.dtgPenalties.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgPenalties.Size = new System.Drawing.Size(350, 392);
            this.dtgPenalties.TabIndex = 0;
            this.dtgPenalties.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgPenalties_CellClick);
            // 
            // GroupBox10
            // 
            this.GroupBox10.Controls.Add(this.txthours);
            this.GroupBox10.Controls.Add(this.txtamount);
            this.GroupBox10.Controls.Add(this.Label29);
            this.GroupBox10.Controls.Add(this.Label2);
            this.GroupBox10.Controls.Add(this.Label30);
            this.GroupBox10.Location = new System.Drawing.Point(6, 89);
            this.GroupBox10.Name = "GroupBox10";
            this.GroupBox10.Size = new System.Drawing.Size(411, 80);
            this.GroupBox10.TabIndex = 17;
            this.GroupBox10.TabStop = false;
            this.GroupBox10.Text = "Payment Per Hours";
            // 
            // txtamount
            // 
            this.txtamount.Location = new System.Drawing.Point(89, 33);
            this.txtamount.Name = "txtamount";
            this.txtamount.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtamount.Size = new System.Drawing.Size(106, 25);
            this.txtamount.TabIndex = 8;
            this.txtamount.TextChanged += new System.EventHandler(this.txtamount_TextChanged);
            // 
            // Label29
            // 
            this.Label29.AutoSize = true;
            this.Label29.Location = new System.Drawing.Point(23, 36);
            this.Label29.Name = "Label29";
            this.Label29.Size = new System.Drawing.Size(60, 17);
            this.Label29.TabIndex = 7;
            this.Label29.Text = "Amount :";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(358, 36);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(35, 17);
            this.Label2.TabIndex = 9;
            this.Label2.Text = "hour";
            // 
            // Label30
            // 
            this.Label30.AutoSize = true;
            this.Label30.Location = new System.Drawing.Point(201, 36);
            this.Label30.Name = "Label30";
            this.Label30.Size = new System.Drawing.Size(28, 17);
            this.Label30.TabIndex = 9;
            this.Label30.Text = "per";
            // 
            // btnPenClose
            // 
            this.btnPenClose.Location = new System.Drawing.Point(665, 404);
            this.btnPenClose.Name = "btnPenClose";
            this.btnPenClose.Size = new System.Drawing.Size(125, 31);
            this.btnPenClose.TabIndex = 28;
            this.btnPenClose.Text = "Close";
            this.btnPenClose.UseVisualStyleBackColor = true;
            this.btnPenClose.Click += new System.EventHandler(this.btnPenClose_Click);
            // 
            // Label32
            // 
            this.Label32.AutoSize = true;
            this.Label32.Location = new System.Drawing.Point(19, 230);
            this.Label32.Name = "Label32";
            this.Label32.Size = new System.Drawing.Size(119, 17);
            this.Label32.TabIndex = 13;
            this.Label32.Text = "Tendered Amount :";
            // 
            // txtTotPay
            // 
            this.txtTotPay.Enabled = false;
            this.txtTotPay.Location = new System.Drawing.Point(145, 196);
            this.txtTotPay.Name = "txtTotPay";
            this.txtTotPay.Size = new System.Drawing.Size(254, 25);
            this.txtTotPay.TabIndex = 12;
            // 
            // txtOverdueTime
            // 
            this.txtOverdueTime.Enabled = false;
            this.txtOverdueTime.Location = new System.Drawing.Point(120, 35);
            this.txtOverdueTime.Name = "txtOverdueTime";
            this.txtOverdueTime.Size = new System.Drawing.Size(142, 25);
            this.txtOverdueTime.TabIndex = 6;
            // 
            // Label28
            // 
            this.Label28.AutoSize = true;
            this.Label28.Location = new System.Drawing.Point(21, 38);
            this.Label28.Name = "Label28";
            this.Label28.Size = new System.Drawing.Size(93, 17);
            this.Label28.TabIndex = 5;
            this.Label28.Text = "Overdue Time:";
            // 
            // GroupBox9
            // 
            this.GroupBox9.Controls.Add(this.Label34);
            this.GroupBox9.Controls.Add(this.Label35);
            this.GroupBox9.Controls.Add(this.Label36);
            this.GroupBox9.Controls.Add(this.Label37);
            this.GroupBox9.Controls.Add(this.Label38);
            this.GroupBox9.Controls.Add(this.TextBox7);
            this.GroupBox9.Controls.Add(this.Label39);
            this.GroupBox9.Controls.Add(this.Label40);
            this.GroupBox9.Location = new System.Drawing.Point(506, 144);
            this.GroupBox9.Name = "GroupBox9";
            this.GroupBox9.Size = new System.Drawing.Size(45, 25);
            this.GroupBox9.TabIndex = 4;
            this.GroupBox9.TabStop = false;
            this.GroupBox9.Text = "do not touch.Time and Days for the future used. ";
            // 
            // Label27
            // 
            this.Label27.AutoSize = true;
            this.Label27.Location = new System.Drawing.Point(6, 45);
            this.Label27.Name = "Label27";
            this.Label27.Size = new System.Drawing.Size(84, 17);
            this.Label27.TabIndex = 22;
            this.Label27.Text = "Borrower Id :";
            // 
            // btnPenNew
            // 
            this.btnPenNew.Location = new System.Drawing.Point(528, 404);
            this.btnPenNew.Name = "btnPenNew";
            this.btnPenNew.Size = new System.Drawing.Size(125, 31);
            this.btnPenNew.TabIndex = 26;
            this.btnPenNew.Text = "New";
            this.btnPenNew.UseVisualStyleBackColor = true;
            this.btnPenNew.Click += new System.EventHandler(this.btnPenNew_Click);
            // 
            // btnPSave
            // 
            this.btnPSave.Location = new System.Drawing.Point(397, 404);
            this.btnPSave.Name = "btnPSave";
            this.btnPSave.Size = new System.Drawing.Size(125, 31);
            this.btnPSave.TabIndex = 27;
            this.btnPSave.Text = "Save";
            this.btnPSave.UseVisualStyleBackColor = true;
            this.btnPSave.Click += new System.EventHandler(this.btnPSave_Click);
            // 
            // GroupBox7
            // 
            this.GroupBox7.Controls.Add(this.Label4);
            this.GroupBox7.Controls.Add(this.txttothours);
            this.GroupBox7.Controls.Add(this.Label3);
            this.GroupBox7.Controls.Add(this.GroupBox10);
            this.GroupBox7.Controls.Add(this.txtChange);
            this.GroupBox7.Controls.Add(this.Label33);
            this.GroupBox7.Controls.Add(this.txttenderedAmount);
            this.GroupBox7.Controls.Add(this.Label32);
            this.GroupBox7.Controls.Add(this.txtTotPay);
            this.GroupBox7.Controls.Add(this.Label31);
            this.GroupBox7.Controls.Add(this.txtOverdueTime);
            this.GroupBox7.Controls.Add(this.Label28);
            this.GroupBox7.Controls.Add(this.GroupBox9);
            this.GroupBox7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox7.Location = new System.Drawing.Point(383, 35);
            this.GroupBox7.Name = "GroupBox7";
            this.GroupBox7.Size = new System.Drawing.Size(423, 323);
            this.GroupBox7.TabIndex = 25;
            this.GroupBox7.TabStop = false;
            this.GroupBox7.Text = "Payments";
            // 
            // Label31
            // 
            this.Label31.AutoSize = true;
            this.Label31.Location = new System.Drawing.Point(36, 199);
            this.Label31.Name = "Label31";
            this.Label31.Size = new System.Drawing.Size(102, 17);
            this.Label31.TabIndex = 11;
            this.Label31.Text = "Total Payments :";
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.txtSearchPborrower);
            this.GroupBox4.Controls.Add(this.dtgPenalties);
            this.GroupBox4.Controls.Add(this.Label27);
            this.GroupBox4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GroupBox4.Location = new System.Drawing.Point(12, 12);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(365, 471);
            this.GroupBox4.TabIndex = 24;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "View Details of unreturned books with Penalties";
            // 
            // txthours
            // 
            this.txthours.Location = new System.Drawing.Point(252, 33);
            this.txthours.Name = "txthours";
            this.txthours.Size = new System.Drawing.Size(100, 25);
            this.txthours.TabIndex = 10;
            this.txthours.ValueChanged += new System.EventHandler(this.txthours_ValueChanged);
            this.txthours.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txthours_KeyPress);
            // 
            // frmOverdue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 495);
            this.Controls.Add(this.btnPenClose);
            this.Controls.Add(this.btnPenNew);
            this.Controls.Add(this.btnPSave);
            this.Controls.Add(this.GroupBox7);
            this.Controls.Add(this.GroupBox4);
            this.Name = "frmOverdue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Payment";
            this.Load += new System.EventHandler(this.frmOverdue_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtgPenalties)).EndInit();
            this.GroupBox10.ResumeLayout(false);
            this.GroupBox10.PerformLayout();
            this.GroupBox9.ResumeLayout(false);
            this.GroupBox9.PerformLayout();
            this.GroupBox7.ResumeLayout(false);
            this.GroupBox7.PerformLayout();
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txthours)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label Label34;
        internal System.Windows.Forms.TextBox txtChange;
        internal System.Windows.Forms.Label Label33;
        internal System.Windows.Forms.TextBox txttenderedAmount;
        internal System.Windows.Forms.Label Label35;
        internal System.Windows.Forms.Label Label36;
        internal System.Windows.Forms.Label Label37;
        internal System.Windows.Forms.Label Label38;
        internal System.Windows.Forms.TextBox TextBox7;
        internal System.Windows.Forms.Label Label39;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.TextBox txttothours;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label40;
        internal System.Windows.Forms.TextBox txtSearchPborrower;
        internal System.Windows.Forms.DataGridView dtgPenalties;
        internal System.Windows.Forms.GroupBox GroupBox10;
        internal System.Windows.Forms.TextBox txtamount;
        internal System.Windows.Forms.Label Label29;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label Label30;
        internal System.Windows.Forms.Button btnPenClose;
        internal System.Windows.Forms.Label Label32;
        internal System.Windows.Forms.TextBox txtTotPay;
        internal System.Windows.Forms.TextBox txtOverdueTime;
        internal System.Windows.Forms.Label Label28;
        internal System.Windows.Forms.GroupBox GroupBox9;
        internal System.Windows.Forms.Label Label27;
        internal System.Windows.Forms.Button btnPenNew;
        internal System.Windows.Forms.Button btnPSave;
        internal System.Windows.Forms.GroupBox GroupBox7;
        internal System.Windows.Forms.Label Label31;
        internal System.Windows.Forms.GroupBox GroupBox4;
        private System.Windows.Forms.NumericUpDown txthours;
    }
}